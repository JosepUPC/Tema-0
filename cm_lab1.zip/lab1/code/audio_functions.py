import numpy as np
#import sounddevice as sd
from scipy import signal
from scipy.fftpack import dct
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import ScalarFormatter


def show_signals(signal1, signal2, title_1, title_2, fs):

    window1 = signal1[150000-1:150000+round(0.02*fs), 0]
    window2 = signal2[150000-1:150000+round(0.02*fs), 0]

    xw1 = np.correlate(window1,window1,"full")
    xw2 = np.correlate(window2,window2,"full")

    t   = np.linspace(0,                    window1.shape[0]/fs, window1.shape[0])
    tc  = np.linspace(-window1.shape[0]/fs, window1.shape[0]/fs, xw1.shape[0]);

    W1 = np.fft.fft(xw1)
    W1 = W1[0:round(W1.shape[0]/2)]
    W2 = np.fft.fft(xw2)
    W2 = W2[0:round(W2.shape[0]/2)]
    
    f = np.linspace(0, 0.5, W1.shape[0])


    fig, ax = plt.subplots(2,3)
    h = ax[0][0].plot(t, window1, linewidth=0.5)
    ax[0][0].set_xlabel('Time')
    ax[0][0].set_ylabel('Magnitude')
    h = ax[1][0].plot(t, window2, linewidth=0.5)
    ax[1][0].set_xlabel('Time')
    ax[1][0].set_ylabel('Magnitude')
    h = ax[0][1].plot(tc, xw1, linewidth=0.5)
    ax[0][1].set_xlabel('Time difference')
    ax[0][1].set_ylabel('Magnitude')
    ax[0][1].set_title(title_1)
    h = ax[1][1].plot(tc, xw2, linewidth=0.5)
    ax[1][1].set_xlabel('Time difference')
    ax[1][1].set_ylabel('Magnitude')
    ax[1][1].set_title(title_2)
    
    h = ax[0][2].plot(f, 10*np.log10(np.abs(W1)), linewidth=0.5)
    ax[0][2].set_xlabel('Frequency')
    ax[0][2].set_ylabel('Magnitude [dB]')
    h = ax[1][2].plot(f, 10*np.log10(np.abs(W2)), linewidth=0.5)
    ax[1][2].set_xlabel('Frequency')
    ax[1][2].set_ylabel('Magnitude [dB]')
    plt.tight_layout()

    fig.set_size_inches(9.0,6.0)

    
    corr_coef_signal1 = xw1[window1.shape[0]] / xw1[window1.shape[0]-1]
    corr_coef_signal2 = xw2[window2.shape[0]] / xw2[window2.shape[0]-1]

    return corr_coef_signal1, corr_coef_signal2


def show_speech(speech_part, fs):

    f, ax = plt.subplots()
    
    ax.specgram(speech_part, cmap='jet', xextent=(0,speech_part.shape[0]-1))
    ax.set_xlabel('Samples')
    ax.set_ylabel('Normalized Frequency (x $\pi$ rdians/sample)')

    f.colorbar(cm.ScalarMappable(cmap='jet'), ax=ax, label = 'Power/frequency (dB / (rad(sample))')

    sform = ScalarFormatter()
    sform.set_scientific(True)
    sform.set_powerlimits((-3,3))
    ax.xaxis.set_major_formatter(sform)

    plt.show()
    
    
def play_masked_tone():
    fs      = 44100
    fsine   = 1000
    t       = np.arange(0, 10*fs)
    fmasked = np.linspace(50,3000,t.shape[0])
    signal  = 4 * np.cos(2 * np.pi * (fsine/fs) * t)
    masked  = 0.05 * np.cos(2 * np.pi * (fmasked/fs) * t)

    tot_signal = masked+signal

    f, ax = plt.subplots()
    
    ax.specgram(tot_signal, cmap='jet', xextent=(0, tot_signal.shape[0]-1))
    ax.set_xlabel('Samples')
    ax.set_ylabel('Normalized Frequency (x $\pi$ rdians/sample)')

    f.colorbar(cm.ScalarMappable(cmap='jet'), ax=ax, label = 'Power/frequency (dB / (rad(sample))')

    sform = ScalarFormatter()
    sform.set_scientific(True)
    sform.set_powerlimits((-3,3))
    ax.xaxis.set_major_formatter(sform)
    plt.show()

    return tot_signal/np.max(tot_signal), fs


def transform_speech(speech, fs):

    err = speech[1:] - speech[0:-1]
    L = round(0.02*fs);
    s = round(L/2);

    t = np.linspace(0,speech.shape[0]/fs,speech.shape[0])

    W = np.zeros((L, L))
    k = 0
    for ii in range (0,speech.shape[0]-L, s):
        w = speech[ii:ii+L] * signal.triang(L)
        W[k,:] = np.abs(dct(w, axis=0, norm='ortho'))
        k = k +1
    
    fig,ax = plt.subplots(3,1)
    ax[0].plot(t,speech, linewidth=0.5)
    ax[0].set_xlabel('Time')
    ax[0].set_ylabel('Magnitude')

    ax[1].plot(W[99,:], linewidth=0.5)
    ax[1].set_xlabel('Coefficient number')
    ax[1].set_ylabel('Magnitude')

    ax[2].plot(W[9,:], linewidth=0.5)
    ax[2].set_xlabel('Coefficient number')
    ax[2].set_ylabel('Magnitude')

    
    #view(0,90);axis tight;
    plt.tight_layout()
    plt.show()


def mulaw(speech, fs, L):

    m   = 255
    mu  = np.sign(speech)*np.log(1+m*np.abs(speech))/np.log(1+m)

    sq  = np.round(speech/L) * L
    sqm = np.round(mu/L) * L

    imu = np.sign(sqm) * (1/m) * ((1+m)**np.abs(sqm)-1)

    fig, ax = plt.subplots(3,1)
    ax[0].plot(speech, linewidth=0.5)
    ax[0].set_title('Original');

    ax[1].plot(sq, linewidth=0.5)
    ax[1].set_title('Quantized uniformly');
    
    ax[2].plot(imu, linewidth=0.5)
    ax[2].set_title('Mu-law Quantized');

    sform = ScalarFormatter()
    sform.set_scientific(True)
    sform.set_powerlimits((-3,3))
    ax[0].xaxis.set_major_formatter(sform)
    ax[1].xaxis.set_major_formatter(sform)
    ax[2].xaxis.set_major_formatter(sform)

    
    plt.tight_layout()
    plt.show()

    return sq, imu


def quantize_error(speech, fs, L):

    err     = np.zeros(speech.shape[0])
    err[1:] = speech[1:]- speech[0:-1]
    qe      = np.round(err/L)*L
    s       = speech[0]
    for ii in range(1, speech.shape[0]): 
        res = speech[ii] - s;
        err[ii] = np.round(res/L)*L
        s = s + err[ii]

    rs = speech.copy()
    err[0] = 0
    for ii in range(1, speech.shape[0]): 
        rs[ii] = rs[ii-1] + err[ii-1]

    plt.plot(rs, linewidth=0.5)
    plt.title('Quantized error signal')
    plt.show()

    return rs,fs
