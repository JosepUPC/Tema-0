import cv2
import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf

def predictive_model_image(lenna_gray):

    #lenna        = cv2.imread('images/lenna.png');
    #lenna_gray   = cv2.cvtColor(lenna, cv2.COLOR_BGR2GRAY).astype(float) # convert to gray
    height,width = lenna_gray.shape[0:2]

    predictive   = np.zeros((height,width))
    for ii in range(width):
        for jj in range(height):
            if ii==1 and jj==1:
                predictive[ii,jj] = lenna_gray[ii,jj]
            elif ii==1:
                predictive[ii,jj] = lenna_gray[ii,jj-1]
            elif jj==1:
                predictive[ii,jj] = (lenna_gray[ii-1,jj]+lenna_gray[ii-1,jj-1])/2
            elif jj == width-1:
                predictive[ii,jj] = (lenna_gray[ii-1,jj-1]+lenna_gray[ii-1,jj]+lenna_gray[ii,jj-1])/3
            else:
                predictive[ii,jj] = (lenna_gray[ii-1,jj-1]+lenna_gray[ii-1,jj]+lenna_gray[ii,jj-1]+lenna_gray[ii-1,jj+1])/4

    fir,ax = plt.subplots(1,3)
    ax[0].imshow(lenna_gray.astype(np.uint8), cmap='gray')
    ax[0].set_title('Original Image')
    ax[0].axis('off')

    ax[1].imshow(predictive.astype(np.uint8), cmap='gray')
    ax[1].set_title('Predicted Image')
    ax[1].axis('off')
    ax[2].imshow((lenna_gray-predictive+128).astype(np.uint8), cmap='gray')
    ax[2].set_title('Error Image')
    ax[2].axis('off')
    
    plt.tight_layout()
    
    plt.show()


def predictive_model_speech(speech, fs):

    #speech, fs = sf.read('audio/speech.wav')
    #speech     = speech[44000-1:100000,1]

    err = speech[1:]- speech[0:-1]
    t = np.linspace(0,speech.shape[0]/fs,speech.shape[0])

    fig,ax = plt.subplots(2,1)
    ax[0].plot(t,speech, linewidth=0.5)
    ax[0].set_xlabel('Time')
    ax[0].set_ylabel('Magnitude')
    ax[0].set_title('Original');

    ax[1].plot(t[0:-1], err, linewidth=0.5)
    ax[1].set_xlabel('Time')
    ax[1].set_ylabel('Magnitude')
    ax[1].set_title('Predicted');

    plt.tight_layout()    
    plt.show()
    
    
