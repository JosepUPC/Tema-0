import numpy as np


def psnr_mse_maxerr(X, Xapp):
    X    = X.astype(float)
    Xapp = Xapp.astype(float)

    absD = np.abs(X-Xapp)
    A    = absD**2
    mse  = np.sum(A)/X.size
    psnr = 10.0 * np.log10 (255*255/mse)
    maxerr = np.round(np.max(absD))
    A = X * X
    B = Xapp * Xapp
    L2rat = np.sqrt(np.sum(B)/np.sum(A))

    return psnr, mse, maxerr, L2rat

